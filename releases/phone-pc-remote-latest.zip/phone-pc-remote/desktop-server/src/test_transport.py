import contextlib
import io
import json
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

import server
from capability_check import send_message


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="qareeb-transport-")
        root = Path(self.temp.name)
        mouse = server.MouseController()
        keyboard = server.KeyboardController()
        mouse.dry_run = keyboard.dry_run = True
        self.state = server.ServerState(local_ip="127.0.0.1")
        self.patches = patch.multiple(
            server, DATA_DIR=root, TRUSTED_DEVICES_PATH=root / "devices.json",
            SETTINGS_PATH=root / "settings.json", EVENT_LOG_PATH=root / "events.log",
            STATE=self.state, MOUSE=mouse, KEYBOARD=keyboard,
        )
        self.patches.start()
        self.output = contextlib.redirect_stdout(io.StringIO())
        self.output.__enter__()
        self.token = self.state.trust_device("test-phone", "Test phone")
        self.tcp = server.ThreadedTcpServer(("127.0.0.1", 0), server.RemoteControlHandler)
        self.port = self.tcp.server_address[1]
        self.worker = threading.Thread(target=self.tcp.serve_forever, daemon=True)
        self.worker.start()

    def tearDown(self):
        self.tcp.shutdown()
        self.tcp.server_close()
        self.worker.join()
        self.output.__exit__(None, None, None)
        self.patches.stop()
        self.temp.cleanup()

    def payload(self, kind, **fields):
        return {"type": kind, "deviceId": "test-phone", "token": self.token, **fields}

    def test_legacy_client_receives_response_and_eof(self):
        with socket.create_connection(("127.0.0.1", self.port), timeout=2) as client:
            client.sendall(b'{"type":"ping"}\n')
            with client.makefile("rb") as reader:
                self.assertEqual(json.loads(reader.readline())["type"], "pong")

    def test_one_shot_pairing_reply_is_followed_by_eof(self):
        with socket.create_connection(("127.0.0.1", self.port), timeout=2) as client:
            client.settimeout(2)
            client.sendall((json.dumps(self.payload("hello", keepAlive=False)) + "\n").encode())
            with client.makefile("rb") as reader:
                reply = json.loads(reader.readline())
                self.assertEqual(reply["type"], "hello_ok")
                self.assertEqual(reply["deviceId"], "test-phone")
                self.assertEqual(reader.read(), b"")
                self.assertEqual(reader.readline(), b"")

    def test_pipelined_inputs_are_processed_in_order(self):
        values = [str(i) for i in range(100)]
        with patch.object(server.KEYBOARD, "type_text") as type_text:
            with socket.create_connection(("127.0.0.1", self.port), timeout=3) as client:
                client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                client.sendall(b"".join(
                    (json.dumps(self.payload("type_text", text=value, keepAlive=True)) + "\n").encode()
                    for value in values
                ))
                with client.makefile("rb") as reader:
                    for _ in values:
                        self.assertEqual(json.loads(reader.readline())["type"], "keyboard_ok")
            self.assertEqual([call.args[0] for call in type_text.call_args_list], values)

    def test_concurrent_activity_has_no_file_collisions_or_per_command_writes(self):
        def request(_):
            return send_message("127.0.0.1", self.port, self.payload("get_settings"))

        self.state.last_saved_at = 0
        with patch.object(server, "save_json_file", wraps=server.save_json_file) as save:
            with ThreadPoolExecutor(max_workers=8) as pool:
                responses = list(pool.map(request, range(200)))
            self.assertTrue(all(item["type"] == "settings" for item in responses))
            self.assertEqual(save.call_count, 1)
        persisted = json.loads(server.TRUSTED_DEVICES_PATH.read_text())
        self.assertEqual(persisted["devices"]["test-phone"]["token"], self.token)

    def test_concurrent_pairing_saves_all_devices(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(lambda i: self.state.trust_device(f"phone-{i}", "Test"), range(32)))
        persisted = json.loads(server.TRUSTED_DEVICES_PATH.read_text())
        self.assertEqual(len(persisted["devices"]), 33)
        self.assertTrue(self.state.forget_device("phone-1"))
        self.assertNotIn("phone-1", json.loads(server.TRUSTED_DEVICES_PATH.read_text())["devices"])

    def test_auth_is_rechecked_on_persistent_connection(self):
        with socket.create_connection(("127.0.0.1", self.port), timeout=2) as client:
            with client.makefile("rb") as reader:
                request = (json.dumps(self.payload("get_settings", keepAlive=True)) + "\n").encode()
                client.sendall(request)
                self.assertEqual(json.loads(reader.readline())["type"], "settings")
                self.state.forget_device("test-phone")
                client.sendall(request)
                self.assertEqual(json.loads(reader.readline())["reason"], "unauthorized")

    def test_lost_pairing_response_can_be_confirmed_without_rotating_token(self):
        requested = "test-pending-token-0123456789012345"
        request = {"type": "hello", "deviceId": "lost-reply-phone", "pairingCode": "111111",
                   "requestedToken": requested, "keepAlive": True, "requestId": "lost-pair"}
        original = server.RemoteControlHandler.send_json
        dropped = threading.Event()

        def drop_first(handler, response):
            if response.get("type") == "paired" and not dropped.is_set():
                dropped.set()
                return
            original(handler, response)

        with patch.object(server.RemoteControlHandler, "send_json", drop_first):
            with self.assertRaises(TimeoutError):
                send_message("127.0.0.1", self.port, request, timeout=.2)
            self.assertTrue(dropped.is_set())
            confirmed = send_message("127.0.0.1", self.port, {
                "type": "hello", "deviceId": "lost-reply-phone", "token": requested,
                "requestId": "confirm-pair", "keepAlive": True,
            })
        self.assertEqual(confirmed["type"], "hello_ok")
        self.assertEqual(confirmed["requestId"], "confirm-pair")
        self.assertTrue(self.state.is_trusted("lost-reply-phone", requested))

    def test_pairing_with_valid_saved_token_does_not_adopt_unused_candidate(self):
        response = send_message("127.0.0.1", self.port, self.payload(
            "hello", pairingCode="111111", requestedToken="unused-new-token-0123456789012345",
            keepAlive=True,
        ))
        self.assertEqual(response["type"], "hello_ok")
        self.assertTrue(self.state.is_trusted("test-phone", self.token))
        self.assertFalse(self.state.is_trusted("test-phone", "unused-new-token-0123456789012345"))

    def test_existing_capabilities_on_isolated_dry_run_server(self):
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name("capability_check.py")), "--port", str(self.port)],
            capture_output=True, text=True, timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("passed=14 failed=0", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
