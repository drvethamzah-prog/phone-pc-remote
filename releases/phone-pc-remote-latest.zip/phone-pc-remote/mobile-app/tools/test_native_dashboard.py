"""Run Android instrumentation against an isolated real server with a recording keyboard.

The test listener is loopback-only. It never sends input to Windows or modifies the
production server's device store. --preview holds the instrumented Activity for UI checks.
"""
import argparse
from pathlib import Path
import socketserver
import subprocess
import sys
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "desktop-server/src"))
import server
server.print = lambda *args, **kwargs: None


class RecordingKeyboard:
    dry_run = True

    def __init__(self):
        self.lock = threading.RLock()
        self.text = ""
        self.events = []
        self.errors = 0
        self.close_preview = False
        self.hello_keep_alive = None

    def is_available(self):
        return True

    def type_text(self, text):
        with self.lock:
            self.text += text
            self.events.append({"insert": text})

    def press_key(self, vk, modifiers=None, count=1):
        with self.lock:
            if vk == server.NAMED_KEYS["backspace"]:
                self.text = self.text[:-count]
            elif vk == server.NAMED_KEYS["enter"]:
                self.text += "\n" * count
            self.events.append({"key": vk, "modifiers": modifiers or [], "count": count})


class Handler(server.RemoteControlHandler):
    def send_json(self, payload):
        if payload.get("type") == "error":
            server.KEYBOARD.errors += 1
        super().send_json(payload)

    def handle_message(self, message):
        kind = message.get("type")
        if kind == "hello":
            server.KEYBOARD.hello_keep_alive = message.get("keepAlive")
        if kind in ("test_snapshot", "test_finish_preview", "test_reset"):
            with server.KEYBOARD.lock:
                if kind == "test_finish_preview":
                    server.KEYBOARD.close_preview = True
                if kind == "test_reset":
                    server.KEYBOARD.text = ""
                    server.KEYBOARD.events.clear()
                self.send_json({"type": "test_snapshot", "text": server.KEYBOARD.text,
                                "events": server.KEYBOARD.events, "errors": server.KEYBOARD.errors,
                                "controlEnabled": server.STATE.control_enabled,
                                "helloKeepAlive": server.KEYBOARD.hello_keep_alive,
                                "closePreview": server.KEYBOARD.close_preview})
            return
        super().handle_message(message)


class TestServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--language", choices=("ar", "en", "system"), default="ar")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="qareeb-native-test-") as folder:
        server.DATA_DIR = Path(folder)
        server.TRUSTED_DEVICES_PATH = server.DATA_DIR / "devices.json"
        server.SETTINGS_PATH = server.DATA_DIR / "settings.json"
        server.EVENT_LOG_PATH = server.DATA_DIR / "events.log"
        server.STATE = server.ServerState()
        server.STATE.trust_device("dashboard-instrumentation", "Android test", "dashboard-test-token")
        server.KEYBOARD = RecordingKeyboard()
        server.MOUSE.dry_run = True
        with TestServer(("127.0.0.1", 0), Handler) as listener:
            port = listener.server_address[1]
            thread = threading.Thread(target=listener.serve_forever, daemon=True)
            thread.start()
            print("TEST_PORT=" + str(port), flush=True)
            command = [str(ROOT / ".android-sdk/platform-tools/adb.exe"), "-s", "emulator-5554", "shell", "am", "instrument",
                       "-w", "-r", "-e", "port", str(port), "-e", "language", args.language]
            if args.preview:
                command += ["-e", "preview", "true"]
            command += ["com.phonepcremote.test/com.phonepcremote.KeyboardInstrumentation"]
            try:
                result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", timeout=420)
                print(result.stdout, flush=True)
                print(result.stderr, flush=True)
                if result.returncode or "PASS " not in result.stdout or "FAIL " in result.stdout:
                    raise RuntimeError("Android instrumentation failed")
                print("PASS isolated server errors=", server.KEYBOARD.errors)
            finally:
                listener.shutdown()
                thread.join(5)


if __name__ == "__main__":
    main()
