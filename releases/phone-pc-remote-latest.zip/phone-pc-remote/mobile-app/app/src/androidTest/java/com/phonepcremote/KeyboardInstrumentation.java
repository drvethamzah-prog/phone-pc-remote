package com.phonepcremote;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import org.json.JSONObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/** Runs against real Android Editable/InputConnection; no external test framework required. */
public final class KeyboardInstrumentation extends Instrumentation {
    private final StringBuilder report = new StringBuilder();
    private Bundle arguments;
    private int assertions;

    @Override public void runOnMainSync(Runnable runnable) {
        java.util.concurrent.atomic.AtomicReference<Throwable> failure = new java.util.concurrent.atomic.AtomicReference<>();
        super.runOnMainSync(() -> { try { runnable.run(); } catch (Throwable error) { failure.set(error); } });
        if (failure.get() != null) throw new AssertionError(failure.get());
    }

    @Override public void onCreate(Bundle args) { arguments = args; start(); }

    private void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        assertions++;
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            runOnMainSync(this::testInputConnection);
            if (arguments != null && arguments.containsKey("port")) testDesktopTransport();
            result.putString("stream", "\nPASS " + assertions + " assertions\n" + report);
            finish(Activity.RESULT_OK, result);
        } catch (Throwable error) {
            result.putString("stream", "\nFAIL " + error + "\n" + android.util.Log.getStackTraceString(error));
            finish(Activity.RESULT_CANCELED, result);
        }
    }

    private void testInputConnection() {
        StringBuilder remote = new StringBuilder();
        ArrayList<LiveTextDelta> events = new ArrayList<>();
        RemoteKeyboardInput input = new RemoteKeyboardInput(getTargetContext(), new RemoteKeyboardInput.Listener() {
            @Override public boolean onEdit(LiveTextDelta edit) {
                events.add(edit);
                int remove = Math.min(edit.backspaces, remote.codePointCount(0, remote.length()));
                remote.setLength(remote.offsetByCodePoints(remote.length(), -remove));
                remote.append(edit.text);
                return true;
            }
            @Override public void onSpecialKey(String key) { remote.append("<").append(key).append(">"); }
        });
        InputConnection ime = input.onCreateInputConnection(new EditorInfo());
        ime.setComposingText("s", 1);
        check(remote.toString().equals("s"), "first composing letter was delayed");
        ime.setComposingText("sa", 1);
        check(remote.toString().equals("sa"), "second composing letter");
        int count = events.size();
        ime.commitText("sa", 1);
        check(remote.toString().equals("sa") && count == events.size(), "commit duplicated composition");
        ime.commitText(" ", 1);
        ime.setComposingText("teh", 1);
        ime.commitText("the", 1);
        check(remote.toString().equals("sa the"), "autocorrection replacement");
        ime.deleteSurroundingText(1, 0);
        check(remote.toString().equals("sa th"), "surrounding deletion");
        input.resetContext(); remote.setLength(0); events.clear();
        ime = input.onCreateInputConnection(new EditorInfo());
        ime.setComposingText("\u0633", 1);
        check(remote.toString().equals("\u0633"), "first Arabic letter was delayed");
        ime.setComposingText("\u0633\u0644", 1);
        check(remote.toString().equals("\u0633\u0644"), "second Arabic letter");
        ime.setComposingText("\u0633\u0644\u0627\u0645", 1);
        count = events.size();
        ime.finishComposingText();
        check(remote.toString().equals("\u0633\u0644\u0627\u0645") && count == events.size(), "finish duplicated Arabic");
        input.backspace();
        check(remote.toString().equals("\u0633\u0644\u0627"), "toolbar deletion lost IME context");
        input.resetContext();
        check(remote.toString().equals("\u0633\u0644\u0627"), "context reset deleted remote text");
        ime = input.onCreateInputConnection(new EditorInfo());
        ime.deleteSurroundingText(1, 0);
        check(remote.toString().equals("\u0633\u0644"), "backspace at empty local buffer");
        count = events.size();
        ime.deleteSurroundingText(0, 0);
        check(events.size() == count, "zero deletion emitted backspace");
        input.resetContext(); remote.setLength(0);
        ime.beginBatchEdit(); ime.beginBatchEdit();
        ime.setComposingText("a", 1); ime.setComposingText("ab", 1);
        check(remote.length() == 0, "batch leaked intermediate state");
        ime.endBatchEdit();
        check(remote.length() == 0, "nested batch ended early");
        ime.endBatchEdit();
        check(remote.toString().equals("ab"), "batch not flushed");
        ime.commitText("ab", 1);
        check(remote.toString().equals("ab"), "batch commit duplicated");
        input.resetContext(); remote.setLength(0);
        ime.commitText("\uD83D\uDE00", 1);
        ime.deleteSurroundingTextInCodePoints(1, 0);
        check(remote.length() == 0, "Unicode code point deletion");
        ime.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
        ime.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
        check(remote.toString().equals("<enter>"), "Enter duplicated key up");
        ime.performEditorAction(EditorInfo.IME_ACTION_DONE);
        check(remote.toString().equals("<enter><enter>"), "IME editor action");
        RemoteKeyboardInput blocked = new RemoteKeyboardInput(getTargetContext(), new RemoteKeyboardInput.Listener() {
            @Override public boolean onEdit(LiveTextDelta edit) { return false; }
            @Override public void onSpecialKey(String key) { }
        });
        blocked.onCreateInputConnection(new EditorInfo()).commitText("not sent", 1);
        check(blocked.getText().length() == 0, "rejected input retained stale context");
        report.append("Android IME: composition, commit, Arabic, correction, deletion, nested batches, Enter, reset, rejected input.\n");
    }

    private Object field(Activity activity, String name) throws Exception {
        Field field = MainActivity.class.getDeclaredField(name); field.setAccessible(true); return field.get(activity);
    }

    private void invoke(Activity activity, String name, Class<?>[] types, Object... args) {
        runOnMainSync(() -> {
            try { Method method = MainActivity.class.getDeclaredMethod(name, types); method.setAccessible(true); method.invoke(activity, args); }
            catch (Exception error) { throw new RuntimeException(error); }
        });
    }

    private JSONObject snapshot(int port) throws Exception {
        try (ControlConnection connection = new ControlConnection(1500)) {
            return new JSONObject(connection.exchange("10.0.2.2", port, "{\"type\":\"test_snapshot\"}"));
        }
    }

    private void expectRemote(int port, String text) throws Exception {
        for (int i = 0; i < 60; i++) {
            if (text.equals(snapshot(port).optString("text"))) { assertions++; return; }
            Thread.sleep(25);
        }
        throw new AssertionError("Desktop text mismatch: " + snapshot(port));
    }

    private View findAction(View view, String label) {
        if (view.isClickable() && (label.contentEquals(view.getContentDescription() == null ? "" : view.getContentDescription())
                || view instanceof TextView && label.contentEquals(((TextView) view).getText()))) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View match = findAction(group.getChildAt(i), label);
                if (match != null) return match;
            }
        }
        return null;
    }

    private void testRemoteButtons(Activity activity, int port) throws Exception {
        invoke(activity, "showScreen", new Class<?>[]{int.class}, 1);
        int[] labels = {R.string.ui_015, R.string.ui_016, R.string.ui_017, R.string.ui_018,
                R.string.ui_019, R.string.ui_020, R.string.ui_022, R.string.ui_023};
        int[] keys = {0xB1, 0xB3, 0xB0, 0xAF, 0xAD, 0xAE, 0x43, 0x56, 0x09};
        View root = ((View[]) field(activity, "screens"))[1];
        for (int i = 0; i < keys.length; i++) {
            String label = i < labels.length ? activity.getString(labels[i]) : "Alt+Tab";
            int before = snapshot(port).getJSONArray("events").length();
            runOnMainSync(() -> {
                View action = findAction(root, label);
                if (action == null) throw new AssertionError("Missing remote button: " + label);
                action.performClick();
            });
            JSONObject event = null;
            for (int attempt = 0; attempt < 60; attempt++) {
                org.json.JSONArray events = snapshot(port).getJSONArray("events");
                if (events.length() > before) { event = events.getJSONObject(before); break; }
                Thread.sleep(25);
            }
            check(event != null && event.optInt("key") == keys[i], "Wrong remote command: " + label);
            if (i >= 6) check(event.getJSONArray("modifiers").getInt(0) == (i == 8 ? 0x12 : 0x11), "Shortcut modifier: " + label);
        }
        invoke(activity, "showScreen", new Class<?>[]{int.class}, 0);
        report.append("Remote: nine real button clicks; transport, volume, mute, copy, paste, Alt+Tab accepted.\n");
    }

    private void testDesktopTransport() throws Exception {
        int port = Integer.parseInt(arguments.getString("port"));
        SharedPreferences prefs = getTargetContext().getSharedPreferences("phone_pc_remote", Context.MODE_PRIVATE);
        Map<String, ?> saved = prefs.getAll();
        Activity activity = null;
        try {
            prefs.edit().clear().putString("device_id", "dashboard-instrumentation").putString("host", "10.0.2.2")
                    .putString("ui_language", arguments.getString("language", "ar"))
                    .putInt("port", port).putString("token", "dashboard-test-token").putBoolean("keyboard_open", false).commit();
            Intent intent = new Intent(getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity = startActivitySync(intent);
            for (int i = 0; i < 100 && !(boolean) field(activity, "connected"); i++) Thread.sleep(50);
            check((boolean) field(activity, "connected"), "real activity did not reconnect");
            check(!snapshot(port).optBoolean("helloKeepAlive", true), "pairing must use a one-shot connection");
            boolean arabic = "ar".equals(activity.getResources().getConfiguration().getLocales().get(0).getLanguage());
            check(activity.getString(R.string.ui_008).equals(arabic ? "\u0627\u0644\u0623\u062c\u0647\u0632\u0629" : "Devices"), "localized navigation");
            check(activity.getWindow().getDecorView().getLayoutDirection() == (arabic ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR), "locale direction");
            check("dashboard-test-token".equals(prefs.getString("token", "")), "language changed pairing token");
            report.append("Locale: ").append(arguments.getString("language", "ar")).append("; labels, direction, pairing preserved.\n");
            waitForIdleSync();
            RemoteKeyboardInput input = (RemoteKeyboardInput) field(activity, "textInput");
            InputConnection[] ime = new InputConnection[1];
            runOnMainSync(() -> { input.requestFocus(); ime[0] = input.onCreateInputConnection(new EditorInfo()); });
            runOnMainSync(() -> ime[0].setComposingText("s", 1)); expectRemote(port, "s");
            runOnMainSync(() -> ime[0].setComposingText("sa", 1)); expectRemote(port, "sa");
            runOnMainSync(() -> ime[0].commitText("sa", 1)); expectRemote(port, "sa");
            runOnMainSync(() -> { ime[0].commitText(" ", 1); ime[0].setComposingText("\u0633", 1); });
            expectRemote(port, "sa \u0633");
            runOnMainSync(() -> ime[0].setComposingText("\u0633\u0644\u0627\u0645", 1));
            expectRemote(port, "sa \u0633\u0644\u0627\u0645");
            runOnMainSync(() -> ime[0].commitText("\u0633\u0644\u0627\u0645", 1));
            runOnMainSync(input::backspace); expectRemote(port, "sa \u0633\u0644\u0627");
            invoke(activity, "controlStop", new Class<?>[0]);
            for (int i = 0; i < 60 && snapshot(port).optBoolean("controlEnabled"); i++) Thread.sleep(25);
            check(!snapshot(port).optBoolean("controlEnabled"), "stop did not reach server");
            runOnMainSync(() -> ime[0].commitText("blocked", 1)); expectRemote(port, "sa \u0633\u0644\u0627");
            invoke(activity, "controlStart", new Class<?>[0]);
            for (int i = 0; i < 60 && (boolean) field(activity, "controlsStopped"); i++) Thread.sleep(25);
            check(!(boolean) field(activity, "controlsStopped"), "resume did not acknowledge");
            runOnMainSync(() -> ime[0].commitText("!", 1)); expectRemote(port, "sa \u0633\u0644\u0627!");
            for (int screen : new int[]{1, 2, 0}) {
                invoke(activity, "showScreen", new Class<?>[]{int.class}, screen);
                View[] screens = (View[]) field(activity, "screens");
                check(screens[screen].getVisibility() == View.VISIBLE, "navigation screen missing");
            }
            testRemoteButtons(activity, port);
            check(snapshot(port).optInt("errors") == 0, "server rejected commands");
            report.append("Desktop transport: real Activity + IME to isolated Python server, every letter before commit, no duplication, Arabic, stop/resume, tabs.\n");
            if ("true".equals(arguments.getString("preview"))) {
                invoke(activity, "openRemoteKeyboard", new Class<?>[0]);
                Bundle progress = new Bundle(); progress.putString("stream", "PREVIEW_READY\n"); sendStatus(1, progress);
                for (int i = 0; i < 300 && !snapshot(port).optBoolean("closePreview"); i++) Thread.sleep(1000);
            }
        } finally {
            if (activity != null) { Activity target = activity; runOnMainSync(target::finish); waitForIdleSync(); }
            SharedPreferences.Editor restore = prefs.edit().clear();
            for (Map.Entry<String, ?> entry : saved.entrySet()) {
                Object value = entry.getValue(); String key = entry.getKey();
                if (value instanceof String) restore.putString(key, (String) value);
                else if (value instanceof Boolean) restore.putBoolean(key, (Boolean) value);
                else if (value instanceof Integer) restore.putInt(key, (Integer) value);
                else if (value instanceof Long) restore.putLong(key, (Long) value);
                else if (value instanceof Float) restore.putFloat(key, (Float) value);
                else if (value instanceof Set) restore.putStringSet(key, (Set<String>) value);
            }
            restore.commit();
        }
    }
}
