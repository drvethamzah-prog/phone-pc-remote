# Changelog

## 0.32.0-pairing-response

- Send hello on a one-shot connection rather than requesting persistence on a disposable socket; retain persistent transport for input commands.
- Use the existing 7-second response timeout for pairing instead of the shorter 3-second timeout. Preserve bounded handshake-only retries and saved/candidate credentials.
- Add regression checks for a hello reply followed by EOF and Android's one-shot hello flag. The reported physical-phone response timeout still requires validation on that phone; its root cause is not confirmed.
- Android app version: 0.28.0-pairing-response.

## 0.31.0-media-remote

- Redesign Media as a compact, centered remote with a prominent circular play/pause key, previous/next keys, a vertical volume/mute rocker, and icon-led shortcut keys.
- Remove the oversized music placeholder; constrain remote width and allow scrolling on small screens or with larger text. Retain Arabic/English labels and existing control commands.
- Add instrumentation checks that click all nine remote buttons and verify server-side key codes and shortcut modifiers without affecting the real Windows desktop.
- Android app version: 0.27.0-media-remote.

## 0.30.0-polished-devices

- Refine Devices with a primary connection action, outlined secondary buttons, paired port/code fields, icon-led management rows, and collapsed diagnostics.
- Add persistent Arabic, English, and system-language choices in Devices and Settings; localize UI labels, accessibility descriptions, confirmations, and status messages through Android resources.
- Follow locale direction and retain the selected screen when changing language; preserve saved pairing credentials.
- Android app version: 0.26.0-polished-devices. Native IME/transport checks also cover locale labels, layout direction, and pairing preservation.

## 0.29.0-live-dashboard

- Fix Windows Unicode injection: use the complete Win32 INPUT union (40 bytes on x64) and UTF-16 surrogate pairs. Add four keyboard regression tests; verify real SendInput acceptance with a non-typing key-up probe.
- Replace the long control form with Control, Media, and Devices screens; retain pairing and transport behavior.
- Use a flexible touchpad with the native Android keyboard, compact shortcuts, and an always-visible stop/resume action.
- Forward IME composing text before word confirmation; reconcile corrections and deletion without repeating committed words.
- Clear local composition after target changes, connection failure, and stop; reject queued edit batches atomically when full.
- Handle Android system/keyboard insets and follow the system light/dark appearance; bundle licensed Lucide icons offline.
- Add pure-Java delta tests and Android instrumentation against an isolated recording server.
- Verified native Gboard letter-by-letter input and deletion on the API 35 emulator; Samsung keyboard validation on the physical phone remains pending.
- Android version: `0.25.0-live-dashboard`. No production server protocol change is required.

## 0.28.0-confirmed-pairing

- Remove the timeout fallback that replaced a confirmed credential with an unused token.
- Serialize pairing/reconnection attempts and retain one pending candidate per endpoint.
- Retry a lost handshake reply once with the same credentials; only persist a confirmed token.
- Keep handshake sockets open until the client receives the reply and distinguish connect/read timeouts.
- Add version/request correlation and response timing to server handshake diagnostics without logging tokens.
- Android version: `0.24.0-confirmed-pairing`.

## 0.27.0-low-latency

- Keep control commands on one ordered TCP connection with TCP_NODELAY.
- Coalesce pending pointer movements and discard stale motion after a network stall.
- Bound the input queue and clear it on transport failure without replaying commands.
- Serialize trusted-device writes and persist last-seen activity at most every 30 seconds.
- Preserve one-request compatibility for existing clients; add an in-app RTT measurement.
- Clear stale timeout status when a new control command succeeds.
- Android version: `0.23.0-low-latency`.

## 0.26.0-pairing-token-fallback

- جعل الهاتف يرسل `requestedToken` أثناء الاقتران، ويستطيع حفظه احتياطيا إذا ضاع رد السيرفر وظهرت مهلة.
- جعل Desktop Server يحفظ `requestedToken` الصالح عند الاقتران بدل الاعتماد دائما على token مولد من السيرفر.
- رفع نسخة Android إلى `0.22.0-pairing-token-fallback`.

## 0.25.0-default-pairing-flow

- جعل تطبيق Android يملأ رمز الاقتران `111111` افتراضيا.
- جعل زر `اتصال ذكي` ينفذ الاقتران مباشرة إذا كان رمز الاقتران موجودا.
- إضافة زر `نسيان محلي` لمسح token المحفوظ على الهاتف والبدء من اقتران جديد.
- جعل أمر الرمز في السيرفر يعيد تثبيت الرمز المحدد عند التشغيل بدلا من توليد رمز عشوائي أثناء الاختبار.
- إضافة تسجيل تشخيصي في Desktop Server لنوع الرسالة الواردة أو الاتصال الفارغ.
- إضافة `desktop-server/src/capability_check.py` لفحص قدرة البروتوكول آليا في وضع dry-run.
- رفع نسخة Android إلى `0.21.0-default-pairing-code`.

## 0.24.0-fixed-pairing-code

- تثبيت رمز الاقتران الافتراضي في Desktop Server على `111111` لتسهيل تجربة الهاتف الحقيقي.
- إضافة خيار `--pairing-code` لتغيير الرمز عند تشغيل السيرفر بدون تعديل الكود.

## 0.23.0-pairing-resilience

- تحسين صمود الاقتران وإعادة الاتصال في Android: مهلة أطول لرسائل `hello`.
- منع تكدس أوامر الاتصال خلف فحص الشبكة الطويل بتحويل منفذ التنفيذ الداخلي إلى عدة خيوط.
- تحسين رسالة انتهاء المهلة لتوضح أن الحل هو البحث ثم الاقتران أو إعادة الاتصال.
- رفع نسخة Android إلى `0.20.0-pairing-resilience`.

## 0.22.0-world-class-baseline

- إضافة معيار منتج عالمي لـ `Qareeb Control` مبني على مقارنة مباشرة مع Unified Remote وKDE Connect وPhone Link.
- تحسين واجهة Android: هوية بصرية أوضح، حالة اتصال مصقولة، زر `اتصال ذكي`، حقول وأزرار أكثر احترافية، وتراكباد بصري أفضل.
- تثبيت اتجاه الواجهة RTL بما يناسب الواجهة العربية.
- رفع نسخة Android إلى `0.19.0-world-class-ui`.

## 0.21.0-qareeb-control-plan

- اعتماد اسم المنتج الجديد `Qareeb Control` مع إبقاء اسم المجلد والحزمة التقنية `phone-pc-remote` مؤقتا للتوافق.
- تحديث عنوان تطبيق Android واسم السيرفر وموقع الدعم المحلي.
- مراجعة خطة المشروع لتطابق الواقع الحالي: الهاتف الفعلي اتصل، والماوس يعمل، والبند المفتوح هو تثبيت الكيبورد اللحظي.
- تحويل أزرار الأحرف والأرقام في Android إلى `key_press` مباشر، وجعل `Space` يرسل مفتاح المسافة مباشرة.
- إضافة fallback في Desktop Server لإدخال الأحرف عبر ضغطات مفاتيح Windows قبل مسار Unicode.
- رفع نسخة Android إلى `0.18.0-qareeb-keyboard`.

## 0.20.0-wide-discovery

- توسيع فحص البحث TCP في Android ليشمل النطاق الحالي والنطاقات المجاورة للـ Wi-Fi.
- رفع عدد خيوط الفحص إلى 64 وتمديد نافذة البحث إلى 12 ثانية.
- يستهدف هذا حالة وجود الهاتف على `10.10.11.x` والحاسوب على `10.10.10.x`.
- رفع نسخة Android إلى `0.17.0-wide-discovery`.

## 0.19.0-auto-reconnect

- إضافة إعادة اتصال تلقائية عند فتح تطبيق Android إذا كان token محفوظا.
- جعل زر الاقتران يعيد الاتصال عند ترك رمز الاقتران فارغا وكان الهاتف موثوقا سابقا.
- تحسين رسالة فشل الاتصال لتعرض `host:port` المستهدف.
- رفع نسخة Android إلى `0.16.0-auto-reconnect`.

## 0.18.0-pairing-stability

- جعل Desktop Server يغلق اتصال TCP بعد معالجة رسالة واحدة، بما يطابق نمط تطبيق Android ويمنع اتصالات معلقة.
- زيادة مهلة اتصال Android العادية إلى 5 ثوان.
- جعل زر الاقتران يعتبر `hello_ok` نجاحا إذا كان الهاتف موثوقا سابقا.
- رفع نسخة Android إلى `0.15.0-pairing-stability`.

## 0.17.0-control-surface

- إعادة ترتيب واجهة التحكم في Android إلى قسم ماوس مباشر وقسم لوحة مفاتيح مباشرة.
- إضافة لوحة مفاتيح أزرار داخل التطبيق: الأرقام والحروف وبعض الرموز تكتب فور الضغط عليها عبر `type_text`.
- إبقاء زر `فتح كيبورد الهاتف` للكتابة العربية أو الرموز الإضافية مع الإرسال اللحظي.
- رفع نسخة Android إلى `0.14.0-control-surface`.

## 0.16.0-discovery-scan

- تحسين زر `بحث` في Android: يبدأ بـ UDP discovery ثم ينتقل تلقائيا إلى فحص TCP للشبكة المحلية عند فشل البث.
- إضافة صلاحية `ACCESS_WIFI_STATE` لاشتقاق نطاق Wi-Fi المحلي للفحص.
- فحص المنفذ `8765` عبر رسالة `status` بدون حاجة إلى UDP broadcast.
- رفع نسخة Android إلى `0.13.0-discovery-scan`.

## 0.15.0-hidden-keyboard

- إزالة حقل الكيبورد الظاهر من واجهة Android.
- إضافة زر `فتح الكيبورد` يفتح لوحة مفاتيح الهاتف ويرسل الإدخال للحاسوب عبر مستقبل داخلي مخفي.
- اعتراض `Backspace` و`Enter` من لوحة المفاتيح مباشرة بجانب الأزرار اليدوية.
- رفع نسخة Android إلى `0.12.0-hidden-keyboard`.

## 0.14.0-live-keyboard

- تحويل حقل الكيبورد في Android إلى كتابة مباشرة بدون زر إرسال نص.
- إرسال الحروف الجديدة فور كتابتها عبر `type_text`.
- إرسال الحذف من لوحة الهاتف كأوامر `backspace` متتابعة.
- إضافة زر `مسح الحقل` لمسح نص الهاتف فقط بدون إرسال حذف للحاسوب.
- رفع نسخة Android إلى `0.11.0-live-keyboard`.

## 0.13.0-power-controls

- إضافة أمر `shutdown_computer` في Desktop Server لإطفاء الحاسوب بعد اقتران صالح وتأكيد صريح.
- إضافة أمر `cancel_shutdown` لإلغاء الإطفاء المجدول.
- إضافة قسم `الطاقة` في تطبيق Android مع زر إطفاء مؤكد وزر إلغاء الإطفاء.
- تحديث عميل الاختبار المحلي لدعم أوامر الطاقة مع خيار `--confirm-shutdown`.
- اختبار أوامر الطاقة في وضع `--dry-run-controls` فقط بدون إطفاء الجهاز فعليا.
- رفع نسخة Android إلى `0.10.0-power-controls`.

## 0.12.0-network-discovery

- إضافة UDP discovery في Desktop Server على نفس منفذ الاتصال `8765`.
- رد الاكتشاف يرجع اسم الحاسوب وIP والمنفذ وحالة السيرفر بدون كشف رمز الاقتران أو token.
- إضافة زر `بحث` في تطبيق Android لاكتشاف السيرفر تلقائيا وملء IP/Port.
- رفع نسخة Android إلى `0.9.0-network-discovery`.
- إعادة بناء APK وتحديث النسخة داخل `releases/` وداخل ZIP الرسمي.
## 0.11.0-android-trackpad-polish

- صقل تراكباد Android بإضافة تمرير بإصبعين.
- منع `ScrollView` من خطف حركة السحب أثناء استخدام التراكباد.
- تحديث سطح حالة الاتصال ليظهر أوضح في أعلى التطبيق.
- تحويل إعدادات الحساسية إلى Presets: `بطيء`, `متوازن`, `سريع`.
- جعل نص الاستجابة قابلا للتحديد والنسخ عند الحاجة.
- رفع نسخة Android إلى `0.8.0-trackpad-polish`.
- إعادة بناء APK واختباره على Android Emulator: اختبار سريع، اقتران، سحب تراكباد، نقر ماوس، وPreset سريع.

## 0.10.0-android-emulator-assist

- إضافة تعرف تلقائي على Android Emulator داخل تطبيق Android.
- تعبئة عنوان `10.0.2.2` تلقائيا عندما يعمل التطبيق على المحاكي ولا يوجد IP محفوظ.
- إضافة زر `محاكي` وزر `اختبار سريع` في قسم الاتصال.
- إخفاء قيمة `token` عند عرض JSON الاستجابة داخل واجهة التطبيق.
- رفع نسخة Android إلى `0.7.0-emulator-security-polish`.
- إعادة بناء APK واختباره على Android Emulator: الاختبار السريع، الاقتران، وأمر نقر ماوس في وضع dry-run.
- إضافة APK الجاهز إلى ZIP الرسمي داخل `android-apk/phone-pc-remote-android-debug.apk`.

## 0.9.0-android-emulator-smoke-test

- تثبيت حزمة Android Emulator وصورة `system-images;android-35;google_apis;x86_64`.
- إنشاء جهاز افتراضي محلي باسم `PhonePCRemote_API35` داخل `.android-avd/`.
- تشغيل التطبيق على Android Emulator وتأكيد بقاء `MainActivity` في الواجهة الأمامية.
- اختبار الاقتران من التطبيق مع Desktop Server عبر `10.0.2.2:8765`.
- اختبار أوامر `Ping`, `Status`, نقر الماوس، والتمرير في وضع `--dry-run-controls`.
- حفظ لقطة شاشة وملفات UIAutomator داخل `releases/` كأدلة اختبار محلية.
- استبعاد `.android-avd/` و`.android-home/` من ZIP الرسمي.

## 0.8.0-android-debug-apk

- تثبيت JDK 17 وAndroid Studio وأدوات Android SDK المحلية داخل المشروع.
- تثبيت `platform-tools`, `platforms;android-35`, و`build-tools;35.0.0`.
- تجهيز Gradle محلي داخل `.gradle-local/` للبناء من دون تثبيت Gradle على النظام.
- إضافة `mobile-app/local.properties` لمسار SDK المحلي مع استبعاده من ZIP الرسمي.
- إزالة BOM من ملفات Gradle وJava/XML الخاصة بتطبيق Android حتى ينجح البناء.
- إنتاج APK تجريبي بنجاح في `mobile-app/app/build/outputs/apk/debug/app-debug.apk`.
- نسخ APK الجاهز إلى `releases/phone-pc-remote-android-debug.apk`.
- تحديث استثناءات ZIP حتى لا تدخل أدوات Android وGradle المحلية داخل الحزمة الرسمية.

## 0.7.0-local-settings-support

- إعادة إنشاء موقع الدعم المحلي داخل `website/` مع صفحة تشغيل وأمان واختبار.
- إضافة ملف بصري محلي للموقع داخل `website/assets/local-control-preview.svg`.
- إضافة إعدادات محلية محفوظة في `desktop-server/data/settings.json`.
- إضافة أوامر `get_settings` و`update_settings` المحمية بالـ token.
- دعم إعدادات `mouseSensitivity`, `scrollSensitivity`, و`maxTextLength`.
- تطبيق الحساسية على `mouse_move` و`scroll`.
- جعل حد `type_text` قابلا للتعديل عبر الإعدادات.
- توسيع عميل الاختبار المحلي لدعم قراءة وتحديث الإعدادات.
- إضافة أزرار حساسية أولية في تطبيق Android.
- استبعاد `settings.json` من ملف ZIP الرسمي لأنه ملف تشغيل محلي.

## 0.6.0-local-device-management

- إضافة أوامر إدارة الأجهزة الموثوقة في Desktop Server.
- إضافة `trusted_devices` لعرض الأجهزة الموثوقة بدون كشف tokens.
- إضافة `forget_device` لحذف جهاز موثوق وإبطال token الخاص به.
- إضافة `rotate_pairing_code` لتغيير رمز الاقتران أثناء تشغيل السيرفر.
- إضافة `control_start` لإعادة تفعيل التحكم بعد `control_stop`.
- توسيع عميل الاختبار المحلي لدعم أوامر الإدارة الجديدة.
- إضافة أزرار إدارة مقابلة في تطبيق Android الأولي.
- اختبار مسار الإدارة كاملا في dry-run: عرض الأجهزة، إيقاف/تشغيل التحكم، تغيير الرمز، حذف الجهاز، ورفض token بعد الحذف.

## 0.5.0-android-client-scaffold

- إنشاء مشروع Android أولي داخل `mobile-app/` قابل للاستيراد في Android Studio.
- إضافة `MainActivity` بواجهة اتصال واقتران وتخزين محلي للـ token.
- إضافة TCP client في التطبيق يرسل JSON بسطر واحد إلى Desktop Server.
- إضافة تراكباد أولي يرسل `mouse_move` ونقرة يسار.
- إضافة أزرار ماوس: نقر يمين ويسار وتمرير.
- إضافة واجهة كيبورد لإرسال نص قصير ومفاتيح أساسية.
- إضافة أزرار ميديا واختصارات مثل Copy وPaste وAlt+Tab.
- إضافة زر `control_stop` من التطبيق.
- توثيق أن أدوات Android لم تكن متوفرة في ذلك الإصدار، لذلك لم يكن APK قد أُنتج بعد.

## 0.4.0-local-keyboard-media

- إضافة أوامر كيبورد آمنة: `key_press` و`type_text`.
- إضافة أوامر ميديا عبر `media_control` مثل الصوت والتشغيل والإيقاف.
- إضافة اختصارات محددة عبر `shortcut` مثل copy وpaste وalt_tab وshow_desktop.
- حماية كل أوامر الكيبورد والميديا بـ `deviceId` و`token`.
- إضافة حد أقصى للنصوص القصيرة: 160 حرفا.
- منع تسجيل النصوص المكتوبة في logs.
- توسيع `--dry-run-controls` ليغطي الكيبورد والميديا أيضا.
- توسيع عميل الاختبار المحلي لدعم أوامر الكيبورد والميديا والاختصارات.
- تحديث الخطة والتصميم التقني ووثيقة الأمان وREADME السيرفر.

## 0.3.0-local-mouse-control

- إضافة تحكم ماوس فعلي على Windows عبر Python `ctypes` بدون مكتبات خارجية.
- إضافة أوامر `mouse_move`, `mouse_click`, و`scroll` مع تحقق إلزامي من `deviceId` و`token`.
- إضافة حدود أمان لحركة الماوس والتمرير وعدد النقرات.
- إضافة أمر `control_stop` لإيقاف التحكم حتى إعادة تشغيل السيرفر.
- إضافة خيار `--dry-run-controls` لاختبار أوامر التحكم بدون تحريك المؤشر الحقيقي.
- توسيع عميل الاختبار المحلي لدعم أوامر الماوس.
- تحديث خطة المشروع والتصميم التقني ووثيقة الأمان وREADME السيرفر.

## 0.2.0-local-connection

- إضافة تخزين دائم للأجهزة الموثوقة في Desktop Server.
- إضافة سجل محلي لمحاولات الاتصال والأخطاء.
- إضافة رسالة `status` تعرض اسم الحاسوب و IP والمنفذ وحالة السيرفر.
- إضافة عميل اختبار محلي `desktop-server/src/test_client.py` لتجربة `ping`, `status`, و`hello`.
- تحديث الوثائق لتوضيح تشغيل السيرفر والاختبار اليدوي.
- منع ملفات التشغيل الحساسة مثل tokens و logs من دخول ZIP الرسمي.

## 0.1.0-local-planning

- إنشاء هيكل المشروع المحلي.
- تثبيت مبدأ العمل بدون خدمات أونلاين.
- إضافة خطة زمنية أولية.
- إضافة تصميم الاتصال المحلي بين الهاتف والحاسوب.
- إضافة سكربت إنتاج ملف ZIP واحد.
- إضافة موقع دعم محلي ثابت.
